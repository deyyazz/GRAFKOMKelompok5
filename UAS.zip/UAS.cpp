#include <GL/glut.h>
#include <iostream>

// --- VARIABEL KAMERA ---
float angleY = 0.0f;
float angleX = 10.0f;
float cameraZ = 50.0f;

// --- WARNA ---
float maroon[] = { 0.6f, 0.1f, 0.1f };
float white[] = { 0.95f, 0.95f, 0.95f };
float wallWhite[] = { 0.9f, 0.9f, 0.9f };
float darkGlass[] = { 0.15f, 0.2f, 0.3f };
float gold[] = { 0.8f, 0.7f, 0.0f };
float brightRed[] = { 0.9f, 0.0f, 0.0f };
float pathGray[] = { 0.4f, 0.4f, 0.45f };
float darkGreen[] = { 0.05f, 0.35f, 0.05f }; // Ijo Tua (Rumput)

// --- FUNGSI GAMBAR BALOK ---
void drawCube(float width, float height, float depth, float r, float g, float b) {
    glColor3f(r, g, b);
    glPushMatrix();
    glScalef(width, height, depth);
    glutSolidCube(1.0f);
    glPopMatrix();
}

// --- FUNGSI GAMBAR SEGITIGA ---
void drawFlatTriangle(float baseWidth, float height, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex3f(0.0f, height / 2.0f, 0.0f);
    glVertex3f(-baseWidth / 2.0f, -height / 2.0f, 0.0f);
    glVertex3f(baseWidth / 2.0f, -height / 2.0f, 0.0f);
    glEnd();
}

// --- FUNGSI ORNAMEN SEGITIGA ---
void drawFrontTriangleOrnaments(float xPos, float yStart, float panelHeight, float zPos) {
    float triHeight = 1.5f;
    float triWidth = 1.5f;
    float spacing = 2.0f;
    int count = (int)(panelHeight / spacing);

    for (int i = 0; i < count; i++) {
        float currentY = yStart + (i * spacing);
        float* color = (i % 2 == 0) ? maroon : white;
        glPushMatrix();
        glTranslatef(xPos, currentY, zPos);
        drawFlatTriangle(triWidth, triHeight, color[0], color[1], color[2]);
        glPopMatrix();
    }
}

// --- FUNGSI JENDELA SAMPING ---
void drawSideWallsSimple(float width, float height, float depth, float groundY) {
    int numWindows = 5;
    float gap = depth / numWindows;
    // Hitung posisi Y jendela relatif terhadap ground
    float winY1 = groundY + 3.0f; // Lantai 1
    float winY2 = groundY + 7.5f; // Lantai 2

    for (int i = 0; i < numWindows; i++) {
        float z = -2.0f - (i * gap);
        // Kiri
        glPushMatrix(); glTranslatef(-(width / 2.0f + 0.1f), winY1, z);
        drawCube(0.2f, 3.0f, 2.0f, darkGlass[0], darkGlass[1], darkGlass[2]); glPopMatrix();
        glPushMatrix(); glTranslatef(-(width / 2.0f + 0.1f), winY2, z);
        drawCube(0.2f, 2.5f, 2.0f, darkGlass[0], darkGlass[1], darkGlass[2]); glPopMatrix();

        // Kanan
        glPushMatrix(); glTranslatef((width / 2.0f + 0.1f), winY1, z);
        drawCube(0.2f, 3.0f, 2.0f, darkGlass[0], darkGlass[1], darkGlass[2]); glPopMatrix();
        glPushMatrix(); glTranslatef((width / 2.0f + 0.1f), winY2, z);
        drawCube(0.2f, 2.5f, 2.0f, darkGlass[0], darkGlass[1], darkGlass[2]); glPopMatrix();
    }
}

// --- FUNGSI UTAMA ---
void drawBuilding() {
    float buildingDepth = 25.0f;
    float buildingWidth = 20.0f;
    float buildingHeight = 11.0f;
    float zBodyCenter = -buildingDepth / 2.0f + 1.0f;

    // --- LOGIKA "NEMPEL TANAH" ---
    // Kita tentukan titik Y=0 adalah permukaan lantai teras.
    // Semua tinggi gedung dihitung DARI titik ini ke atas.
    float floorLevel = -4.0f; // Kita turunkan seluruh scene agar pas di kamera

    // Y Pusat Balok = floorLevel + (TinggiBalok / 2)
    // Ini rumus sakti biar baloknya "duduk" manis di atas lantai.

    // 1. BADAN UTAMA
    glPushMatrix();
    glTranslatef(0.0f, floorLevel + (buildingHeight / 2.0f), zBodyCenter);
    drawCube(buildingWidth, buildingHeight, buildingDepth, wallWhite[0], wallWhite[1], wallWhite[2]);
    glPopMatrix();

    // 2. ATAP
    float roofR[] = { 0.7f, 0.3f, 0.2f };
    glPushMatrix();
    glTranslatef(0.0f, floorLevel + buildingHeight + 0.75f, zBodyCenter);
    drawCube(buildingWidth + 2.0f, 1.5f, buildingDepth + 2.0f, roofR[0], roofR[1], roofR[2]);
    glPopMatrix();

    // 3. JENDELA SAMPING
    drawSideWallsSimple(buildingWidth, buildingHeight, buildingDepth, floorLevel);

    // ==========================================================
    // 4. FASAD DEPAN 
    // ==========================================================
    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 1.0f); // Maju dikit

    // A. GAPURA TENGAH (Pilar Merah)
    float pilarH = buildingHeight + 1.0f;
    float pilarY = floorLevel + (pilarH / 2.0f); // Rumus sakti lagi
    float gapuraSpread = 4.0f;

    // Kiri & Kanan
    glPushMatrix(); glTranslatef(-gapuraSpread, pilarY, 0.0f);
    drawCube(2.0f, pilarH, 1.5f, maroon[0], maroon[1], maroon[2]); glPopMatrix();
    glPushMatrix(); glTranslatef(gapuraSpread, pilarY, 0.0f);
    drawCube(2.0f, pilarH, 1.5f, maroon[0], maroon[1], maroon[2]); glPopMatrix();

    // B. ORNAMEN PUTIH & SEGITIGA
    float ornamentX = gapuraSpread + 2.5f;
    // Panel Putih Kiri
    glPushMatrix(); glTranslatef(-ornamentX, floorLevel + (buildingHeight / 2.0f), 0.0f);
    drawCube(3.0f, buildingHeight, 1.0f, wallWhite[0], wallWhite[1], wallWhite[2]); glPopMatrix();
    // Segitiga Kiri
    drawFrontTriangleOrnaments(-ornamentX, floorLevel + 2.0f, 8.0f, 0.55f);

    // Panel Putih Kanan
    glPushMatrix(); glTranslatef(ornamentX, floorLevel + (buildingHeight / 2.0f), 0.0f);
    drawCube(3.0f, buildingHeight, 1.0f, wallWhite[0], wallWhite[1], wallWhite[2]); glPopMatrix();
    // Segitiga Kanan
    drawFrontTriangleOrnaments(ornamentX, floorLevel + 2.0f, 8.0f, 0.55f);

    // C. BAGIAN TENGAH (Papan Nama, Logo, Pintu)
    // Papan Nama
    glPushMatrix(); glTranslatef(0.0f, floorLevel + 5.0f, 0.6f);
    drawCube(7.5f, 1.5f, 0.5f, maroon[0], maroon[1], maroon[2]); glPopMatrix();
    // Garis Putih Teks
    glPushMatrix(); glTranslatef(0.0f, floorLevel + 5.0f, 0.9f);
    drawCube(6.0f, 0.2f, 0.1f, white[0], white[1], white[2]); glPopMatrix();

    // Logo Area
    glPushMatrix(); glTranslatef(0.0f, floorLevel + 9.0f, 0.0f);
    drawCube(7.5f, 3.5f, 0.8f, white[0], white[1], white[2]); glPopMatrix();
    glPushMatrix(); glTranslatef(0.0f, floorLevel + 9.0f, 0.45f);
    drawCube(6.0f, 2.5f, 0.2f, maroon[0], maroon[1], maroon[2]); glPopMatrix();
    glPushMatrix(); glTranslatef(0.0f, floorLevel + 9.2f, 0.6f);
    glColor3f(gold[0], gold[1], gold[2]); glutSolidSphere(0.8f, 20, 20); glPopMatrix();

    // Pintu Kaca (Nempel Lantai)
    glPushMatrix(); glTranslatef(0.0f, floorLevel + 2.0f, 0.2f);
    drawCube(6.0f, 4.0f, 0.1f, darkGlass[0], darkGlass[1], darkGlass[2]); glPopMatrix();

    // D. AWNING (Bendera)
    glPushMatrix(); glTranslatef(0.0f, floorLevel + 4.0f, 1.2f);
    drawCube(14.0f, 0.3f, 0.5f, brightRed[0], brightRed[1], brightRed[2]);
    glTranslatef(0.0f, -0.2f, 0.0f);
    drawCube(14.0f, 0.2f, 0.4f, white[0], white[1], white[2]); glPopMatrix();

    glPopMatrix();

    // ==========================================================
    // 5. ALAS, RUMPUT & JALAN (GROUND)
    // ==========================================================

    // A. TERAS (Lantai Keramik Gedung)
    // Titik pusat Y = floorLevel - (tebal/2). Jadi permukaan atasnya pas di floorLevel.
    glPushMatrix();
    glTranslatef(0.0f, floorLevel - 0.2f, 2.0f);
    drawCube(18.0f, 0.4f, 6.0f, 0.7f, 0.7f, 0.7f); // Abu-abu terang
    glPopMatrix();

    // B. RUMPUT LUAS (Ijo Tua)
    // Posisinya sedikit di bawah teras biar kelihatan beda layer
    glPushMatrix();
    glTranslatef(0.0f, floorLevel - 0.3f, 5.0f);
    drawCube(60.0f, 0.2f, 60.0f, darkGreen[0], darkGreen[1], darkGreen[2]);
    glPopMatrix();

    // C. JALAN (Paving Block) DEPAN GAPURA
    // Dari depan teras memanjang ke kamera
    // Teras ada di Z=2.0 dengan depth 6.0 -> ujung depannya Z = 2.0 + 3.0 = 5.0
    float pathStartZ = 5.0f;
    float pathLength = 30.0f;

    glPushMatrix();
    // Y ditaruh sedikit diatas rumput biar gak "z-fighting" (kedip-kedip)
    glTranslatef(0.0f, floorLevel - 0.25f, pathStartZ + (pathLength / 2.0f));
    drawCube(8.0f, 0.05f, pathLength, pathGray[0], pathGray[1], pathGray[2]);
    glPopMatrix();
}

// --- SETUP ---
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(0.0f, 2.0f, cameraZ, 0.0f, 2.0f, 0.0f, 0.0f, 1.0f, 0.0f);
    glRotatef(angleX, 1.0f, 0.0f, 0.0f);
    glRotatef(angleY, 0.0f, 1.0f, 0.0f);

    GLfloat lightPos[] = { 0.0f, 50.0f, 50.0f, 1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

    drawBuilding();
    glutSwapBuffers();
}

void reshape(int w, int h) {
    if (h == 0) h = 1;
    float ratio = (float)w / h;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45, ratio, 1, 300);
    glMatrixMode(GL_MODELVIEW);
}

void keyboard(unsigned char key, int x, int y) {
    if (key == 27) exit(0);
    if (key == 'w' || key == 'W') cameraZ -= 1.0f;
    if (key == 's' || key == 'S') cameraZ += 1.0f;
    glutPostRedisplay();
}

void specialKeys(int key, int x, int y) {
    if (key == GLUT_KEY_RIGHT) angleY += 3.0f;
    if (key == GLUT_KEY_LEFT) angleY -= 3.0f;
    if (key == GLUT_KEY_UP) angleX -= 3.0f;
    if (key == GLUT_KEY_DOWN) angleX += 3.0f;
    glutPostRedisplay();
}

void init() {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING); glEnable(GL_LIGHT0); glEnable(GL_NORMALIZE);
    glClearColor(0.5f, 0.8f, 0.95f, 1.0f);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1200, 800);
    glutCreateWindow("FH UNESA 3D - Fixed Ground Contact");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
    glutMainLoop();
    return 0;
}